package org.ebay_project.ebaytester.model;

public class DealFPStructure {
	
	String product_img_url;
	String deal_name;
	public DealFPStructure() {
		
	}
	public String getProduct_img_url() {
		return product_img_url;
	}
	public void setProduct_img_url(String product_img_url) {
		this.product_img_url = product_img_url;
	}
	public String getDeal_name() {
		return deal_name;
	}
	public void setDeal_name(String deal_name) {
		this.deal_name = deal_name;
	}
	
	
	

}
