package org.ebay_project.ebaytester.service;

public class PathSetup {
	public static final String imagePath = "/home/amit/Desktop/pro/ebaytester/src/main/webapp/";

}